"""Fail-closed measured-goal receipt; both targets and raw matched controls required."""
import argparse,hashlib,importlib.util,json,math,statistics
from pathlib import Path
SOURCE='54979d50b5cb2e5ae68ece16540d26150957210dc42c4cbfb74508067a3e337e'
ADDON='fab05c99fb5158489345af782f1fdbc53f8630e0ad723dda6e86b399e91a8be4'
PROFILE={'optLevel':3,'lto':True,'codegenUnits':1,'debugAssertions':False,'overflowChecks':False,'debug':0,'incremental':False,'panic':'unwind'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser()
 for name in ['quality','timing32','timing128','hardware','norm98-hardware','build-receipt','output']:p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--comparator',type=Path,default=Path(__file__).resolve().parents[3]/'packages/bench/diffusion-gemma/compare-generation.py')
 a=p.parse_args();pins={}
 def read(path):pins[str(path.resolve())]=sha(path);return json.loads(path.read_text())
 def profile(row):
  assert row['profile']=='release' and row['buildProfile']==PROFILE
  assert row['artifactSubdirectory']=='x86_64-unknown-linux-gnu/release'
 def restored(directory):
  r=read(directory/'restored.json');assert r['restored'] is True and r['addedFilesRemoved'] is True and r['exitCode']==0 and r['errors']==[];return r
 hardware=read(a.hardware);supplement=read(a.norm98_hardware);build=read(a.build_receipt)
 for row in [hardware,supplement,build]:
  profile(row);assert row['sourceArchiveSha256']==SOURCE
 assert build['sha256']==hardware['candidateSha256']==supplement['candidateSha256']==ADDON
 assert '--release' in build['buildCommand']
 assert hardware['status']==supplement['status']=='passed'
 assert {'host','chain97-parity','normrope101-loader-parity','normrope101-compiled-lifecycle','normrope101-lazy-kv-schedule','normrope101-actual-model-tables-kv','softmax100-loader-parity','softmax100-compiled-lifecycle'}<=set(hardware['checks'])
 assert set(supplement['checks'])=={'norm98-loader-parity','norm98-paired-lifecycle','norm98-stateful-mapping'}
 assert supplement['priorHardwareAssessmentSha256']==sha(a.hardware) and supplement['normalAddonUnchanged'] is True
 quality=read(a.quality/'assessment.json');qp=read(a.quality/'provenance.json');qr=restored(a.quality);profile(qp)
 assert quality['status']=='natural-quality-passed' and quality['summary']['candidate-effect']=={'passed':12,'total':12}
 assert quality['newFailuresAgainstBaseline']['candidate-effect']==[] and quality['norm98Enabled'] is True
 assert quality['sampler83Programs']==12 and quality['native97Invocations']>0
 coverage=read(a.quality/'coverage.json');assert coverage['native97Invocations']==coverage['totalRefinements']==quality['native97Invocations']
 assert quality['combinedCoverage']==coverage['combinedCoverage']
 readonly=[]
 for row in quality['combinedCoverage']:
  assert row['access'] in ['Append','ReadOnly'];n=25 if row['width']==256 else 0
  assert row['normrope101']==n and row['aliases101']==2*n
  assert row['norm98Entrance']==row['norm98Tail']==(30 if row['access']=='ReadOnly' else 29)
  if row['access']=='ReadOnly':readonly.append(row)
 assert len(readonly)==2 and all(r['width']==256 for r in readonly) and sorted(r['softmax100'] for r in readonly)==[0,1]
 assert qp['buildArchiveSha256']==SOURCE
 assert qp['candidate']['packages/backend-cuda/dist/internal/effect-torch-backend-cuda.linux-x64-gnu.node']==ADDON
 flags=qp['flags'];assert flags['EFFECT_TORCH_DIFFUSION_PROCESSED_EVALUATION97']=='1'
 assert flags['EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY']=='/root/triton-normalization98-screen-v1' and flags['EFFECT_TORCH_CUDA_FFN_NEXT_NORM63']=='1'
 assert qp['guardedFiles']['/root/triton-normalization98-screen-v1/launch-manifest.json']==supplement['norm98ManifestSha256']
 pins[str(a.comparator.resolve())]=sha(a.comparator)
 assert qp['guardedFiles']['/root/effect-torch/packages/bench/diffusion-gemma/compare-generation.py']==sha(a.comparator)
 spec=importlib.util.spec_from_file_location('goal_compare',a.comparator);compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
 targets=[]
 for target,directory in [(32,a.timing32),(128,a.timing128)]:
  assessment=read(directory/'assessment.json');comparison=read(directory/'comparison-vs-vllm.json');provenance=read(directory/'provenance.json');restoration=restored(directory);profile(provenance)
  assert restoration['baseline']==qr['baseline']
  for key in ['candidate','buildArchiveSha256','profile','buildProfile','artifactSubdirectory','flags']:assert provenance[key]==qp[key],key
  command=provenance['command'];assert command[2]==f'timing{target}' and '--norm98' in command and '--refresh-vllm' in command
  guards=provenance['guardedFiles']
  assert any(k.endswith('/assessment.json') and v==sha(a.quality/'assessment.json') for k,v in guards.items())
  assert any(k.endswith('/provenance.json') and v==sha(a.quality/'provenance.json') for k,v in guards.items())
  assert assessment['status']=='timing-screen-complete' and assessment['freshVllmControl'] is True and assessment['beatsFreshMatchedVllmMedian'] is True and assessment['acceptanceRequiresBothTargets'] is True
  assert comparison['matched'] is True and comparison['differences']==[]
  files={};medians={}
  for engine,key in [('effect','combined97_100_101'),('vllm','vllm')]:
   original=Path(assessment['timing'][key]['source']);assert original.name==f'{engine}-combined97-100-101-release-v1.jsonl'
   assert original.parent.name==f'prompt-{target}' and original.parent.parent==Path(command[command.index('--output')+1])
   found=list(directory.rglob(original.name));assert len(found)==1;file=found[0];files[engine]=file;pins[str(file.resolve())]=sha(file)
   rows=[json.loads(line) for line in file.read_text().splitlines() if line.strip()];assert len(rows)==5 and sorted(r['run'] for r in rows)==list(range(5))
   assert all(r['engine']==('effect-torch' if engine=='effect' else 'vllm') and r['measurementMode']=='timing' for r in rows)
   values=[r['elapsedMilliseconds'] for r in sorted(rows,key=lambda r:r['run'])];assert all(math.isfinite(v) and v>0 for v in values)
   assert values==assessment['timing'][key]['milliseconds'];median=statistics.median(values);assert median==assessment['timing'][key]['medianMs'];medians[engine]=median
  fresh=compare.compare(compare.read(files['effect']),compare.read(files['vllm']));assert fresh==comparison,'recomputed comparator differs'
  assert len(fresh['measurements'])==1;m=fresh['measurements'][0]
  assert (m['promptTokens'],m['outputTokens'],m['concurrency'])==(target,64,1)
  assert m['effectMedianMs']==medians['effect'] and m['vllmMedianMs']==medians['vllm'] and medians['effect']<medians['vllm']
  delta=100*(medians['effect']/medians['vllm']-1);assert math.isclose(delta,assessment['vsVllmPercent'],abs_tol=1e-10)
  targets.append(dict(promptTokens=target,effectMedianMs=medians['effect'],freshVllmMedianMs=medians['vllm'],effectVsVllmPercent=delta,matched=True))
 receipt=dict(status='measured-goal-achieved',scope='Both matched prompt32 and prompt128 five-case medians beat sequential fresh vLLM controls; bounded twelve-task natural quality passed. No broader workload or statistical superiority claim.',sourceArchiveSha256=SOURCE,candidateSha256=ADDON,profile='release',buildProfile=PROFILE,norm98Enabled=True,qualityPassed=12,qualityTotal=12,allRestored=True,targets=targets,inputSha256=pins,validatorSha256=sha(Path(__file__)))
 with a.output.open('x') as file:json.dump(receipt,file,indent=2);file.write('\n')
 print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
