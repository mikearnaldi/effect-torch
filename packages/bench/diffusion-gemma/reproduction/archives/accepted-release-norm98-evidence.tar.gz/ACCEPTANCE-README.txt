Measured-goal validation passed for both completed targets

The accepted-norm98 directory is reserved for the matching release+norm98 candidate. Existing natural/ and timing32/ evidence without norm98 remains unchanged and does not satisfy the goal.

Validation command from repository root (use a fresh --output filename to reproduce; measured-goal.json is preserved create-only):

nix develop --command python3 bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/validate-measured-goal.py \
  --quality bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/accepted-norm98/natural \
  --timing32 bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/accepted-norm98/timing32 \
  --timing128 bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/accepted-norm98/timing128 \
  --hardware bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/build/assessment.json \
  --norm98-hardware bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/accepted-norm98/hardware-norm98/assessment.json \
  --build-receipt bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/build/build-receipt.json \
  --output bench-results/diffusion-gemma-20260930/combined97-100-101-release-evidence-v1/accepted-norm98/measured-goal.json

The validator requires identical candidate/source/release profile/flags and exact quality receipt hashes across both targets, all eight release and three supplemental norm98 hardware checks, 12/12 quality, actual101/100/98 topology, native97 coverage, complete restoration, and fresh five-case controls. It independently recomputes comparison contracts and medians from raw JSONL. The output is create-only and is written only after every check passes. Downloaded raw JSONL may be flat; the validator resolves a unique basename only after validating the original remote path against the run's output command and target. No missing target can be inferred from another result.

Root's measured commands (executed separately under exclusive GPU scheduling):
python3 /root/combined97-100-101-release-entry-v1/run.py natural --norm98 --baseline-natural /root/combined97-100-101-natural-v2/candidate-effect.jsonl --output /root/combined97-98-100-101-release-natural-v1

Timing reproduction requires --quality /root/combined97-98-100-101-release-natural-v1, --norm98, --refresh-vllm, and fresh output paths. The exact --baseline-effect argument and command are preserved in each timing provenance.json. Both use the unchanged seven-case bank at /root/native66-fresh-distinct-v1 with two warmups and five measurements; sequential Effect then vLLM processes include prefill, refinement and full terminal commit. Diagnostic tracing is disabled during measurement.

Claim scope: only the two measured matched target medians and bounded twelve-task natural quality. Margins do not establish broad workload or statistical superiority. Both targets passed and accepted-norm98/measured-goal.json records the pinned evidence.

Exact accepted outer commands, reconstructed from preserved provenance (use fresh output directories for reruns):
python3 /root/combined97-100-101-release-entry-v1/run.py natural --output /root/combined97-98-100-101-release-natural-v1 --baseline-natural /root/combined97-98-100-101-natural-v2/candidate-effect.jsonl --norm98
python3 /root/combined97-100-101-release-entry-v1/run.py timing32 --output /root/combined97-98-100-101-release-timing32-v1 --baseline-natural /root/literal89-plus66-natural-v1/candidate-effect.jsonl --baseline-effect /root/combined97-100-101-release-timing32-v1/prompt-32/effect-combined97-100-101-release-v1.jsonl --norm98 --refresh-vllm --quality /root/combined97-98-100-101-release-natural-v1
python3 /root/combined97-100-101-release-entry-v1/run.py timing128 --output /root/combined97-98-100-101-release-timing128-v1 --baseline-natural /root/literal89-plus66-natural-v1/candidate-effect.jsonl --baseline-effect /root/production97-timing128-v2/prompt-128/effect-production97-v1.jsonl --norm98 --refresh-vllm --quality /root/combined97-98-100-101-release-natural-v1

Measured result: prompt32 median 552.562360ms versus fresh vLLM 554.558223ms (-0.359901%); prompt128 median 530.969076ms versus fresh vLLM 532.181951ms (-0.227906%). Prompt128 won only 2/5 paired cases; median wins do not imply every case was faster or establish statistical confidence. Candidate addon SHA256 fab05c99fb5158489345af782f1fdbc53f8630e0ad723dda6e86b399e91a8be4; source archive SHA256 54979d50b5cb2e5ae68ece16540d26150957210dc42c4cbfb74508067a3e337e. Release profile and --norm98 are both required.
