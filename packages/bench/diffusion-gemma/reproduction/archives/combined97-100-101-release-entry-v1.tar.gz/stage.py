"""Runs only under guarded combined97+100+101 swap; norm98 is explicitly optional and defaults OFF."""
import argparse, hashlib, importlib.util, json, os, statistics, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage',choices=['natural','timing32','timing128']);p.add_argument('--output',type=Path,required=True);p.add_argument('--baseline-natural',type=Path,required=True);p.add_argument('--baseline-effect',type=Path);p.add_argument('--norm98',action='store_true');p.add_argument('--refresh-vllm',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;repo=Path('/root/effect-torch');out=a.output;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert out.is_dir() and (out/'originals').is_dir()
assert os.environ['EFFECT_TORCH_DIFFUSION_PROCESSED_EVALUATION97']=='1'
assert ('EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY' in os.environ)==a.norm98
assert os.environ['EFFECT_TORCH_CUDA_FFN_NEXT_NORM63']==('1' if a.norm98 else '0')
assert os.environ['DIFFUSION_FUSED_READOUT']=='1' and os.environ['EFFECT_TORCH_DIFFUSION_SCALAR_TEMPERATURE93']=='1' and os.environ['EFFECT_TORCH_CUDA_ROTARY_REUSE66']=='1'
env=dict(os.environ)
def run(command,output=None):subprocess.run(command,cwd=repo,env=env,stdout=output,check=True)
if a.stage=='natural':
 private=Path('/root/bf16-quality-policy75');exact89=Path('/root/literal89-plus66-natural-v1/candidate-effect.jsonl');vllm=Path('/root/natural75-vllm-continuation-v1/vllm.jsonl')
 selected=[a.baseline_natural,exact89,vllm,private/'natural75-manifest.json',private/'natural-tasks.json'];pins={str(f):sha(f) for f in selected}
 env.update(MANIFEST=str(private/'natural75-manifest.json'),NATURAL_TASKS75=str(private/'natural-tasks.json'),MODEL_PATH='/root/models/diffusiongemma',INITIALIZED_STATE_PATH='/root/oracle-eager-20260930/initialized-state/initialized-rope.safetensors',OUTPUT=str(out/'candidate-effect.jsonl'),GENERATION_TRACE='1',EFFECT_TORCH_COMPILE_DIAGNOSTICS_PATH=str(out/'compile-diagnostics.jsonl'))
 run(['pnpm','--filter','@effect-torch/bench','exec','tsx','diffusion-gemma/natural93-effect.ts'])
 diagnostics=[json.loads(line) for line in (out/'compile-diagnostics.jsonl').read_text().splitlines()]
 native97=[r for r in diagnostics if r['event']=='native-processed97']
 assert native97 and all(r['hostInputElements']==256 and r['hostElements']==1025 for r in native97)
 diagnostics=[r for r in diagnostics if r['event']=='compile-diagnostics']
 samplers=[r for r in diagnostics if any(i['kind']=='et_random_sampler83_f32' for i in r['diagnostics']['instructions'])]
 assert len(samplers)==12 and all(next(i['count'] for i in r['diagnostics']['instructions'] if i['kind']=='et_random_sampler83_f32')==1 for r in samplers)
 assert all(not any(i['kind']=='et_ffn_next_norm63_bf16' for i in r['diagnostics']['instructions']) for r in diagnostics),'unadmitted nextnorm63 fallback'
 coverage=[]
 for row in diagnostics:
  instructions={i['kind']:i['count'] for i in row['diagnostics']['instructions']}
  entrance98=instructions.get('triton_norm98_entrance',0);tail98=instructions.get('triton_norm98_tail',0)
  norm= instructions.get('triton_normrope101',0);aliases=instructions.get('normrope101_output',0);softmax=instructions.get('triton_softmax100',0)
  assert instructions.get('et_bf16_softmax_prepare',0)==instructions.get('et_bf16_softmax_store',0)==0,'unadmitted full-vocabulary BF16 softmax'
  if instructions.get('fused_moe75',0)==30:
   shapes=row['rootShapes'];assert shapes and all(len(shape)==3 for shape in shapes),shapes
   widths={shape[1] for shape in shapes};assert len(widths)==1,widths
   width=next(iter(widths));expected=25 if width==256 else 0
   assert isinstance(width,int) and width>0
   assert norm==expected and aliases==2*expected,('normrope101 shape coverage',width,norm,aliases)
   access=row['stateAccess'];assert access in ['Append','ReadOnly']
   expected98=(30 if access=='ReadOnly' else 29) if a.norm98 else 0
   assert entrance98==tail98==expected98,('norm98 topology',access,entrance98,tail98)
   if a.norm98:assert instructions.get('et_attention_ffn_entrance_bf16',0)==(0 if access=='ReadOnly' else 1)
   assert softmax in ([0,1] if access=='ReadOnly' and width==256 else [0]),('softmax100 geometry',access,width,softmax)
   coverage.append({'access':access,'width':width,'normrope101':norm,'aliases101':aliases,'softmax100':softmax,'norm98Entrance':entrance98,'norm98Tail':tail98})
  else:assert norm==aliases==softmax==entrance98==tail98==0,'unexpected combined optimization topology'
 readonly=[r for r in coverage if r['access']=='ReadOnly']
 assert len(readonly)==2 and all(r['width']==256 and r['normrope101']==25 for r in readonly),'exact initial/refinement programs required'
 assert sorted(r['softmax100'] for r in readonly)==[0,1],'exactly one true self-conditioning softmax program required'
 records=[json.loads(line) for line in (out/'candidate-effect.jsonl').read_text().splitlines()]
 assert load(private/'natural75-manifest.json')['matrix']['warmupRuns']==0
 assert sorted(r['randomSeed'] for r in samplers)==sorted(seed for row in records for seed in row['requestSeeds']),'request-private sampler seed mismatch'
 total_refinements=sum(sum(row['refinementsPerRequest']) for row in records)
 assert len(native97)==total_refinements,'every quality refinement must execute native97'
 (out/'coverage.json').write_text(json.dumps({'sampler83Programs':12,'native97Invocations':len(native97),'totalRefinements':total_refinements,'norm98Enabled':a.norm98,'combinedCoverage':coverage,'scope':'quality only; timing diagnostics disabled'},indent=2)+'\n')
 run(['/root/.cache/effect-torch/vllm-0.24.0/bin/python',str(here/'score-natural.py'),'--fixture',str(private/'natural-tasks.json'),'--tokenizer','/root/models/diffusiongemma/tokenizer.json','--output',str(out/'scores.json'),'--run',f'baseline={a.baseline_natural}','--run',f'vllm={vllm}','--run',f'candidate-effect={out/"candidate-effect.jsonl"}'])
 spec=importlib.util.spec_from_file_location('exact93',here/'compare-natural93.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 left,right=module.read(a.baseline_natural),module.read(out/'candidate-effect.jsonl');assert left.keys()==right.keys()
 contract=['engine','measurementMode','taskFixtureSha256','model','generation','deployment','promptTokenIds','requestSeeds']
 for key in left:
  for field in contract:assert left[key][field]==right[key][field],(key,field)
 differences=[{'task':list(key),'field':field,'baseline':left[key].get(field),'candidate':right[key].get(field)} for key in left for field in module.FIELDS if left[key].get(field)!=right[key].get(field)]
 (out/'exact-vs-baseline.json').write_text(json.dumps({'exact':not differences,'differences':differences,'scope':'reported only: BF16 kernel changes allowed subject to 12/12quality gate'},indent=2)+'\n')
 scores=load(out/'scores.json');assert scores['summary']['candidate-effect']=={'passed':12,'total':12};assert scores['newFailuresAgainstBaseline']['candidate-effect']==[]
 assessment={'status':'natural-quality-passed','summary':scores['summary'],'newFailuresAgainstBaseline':scores['newFailuresAgainstBaseline'],'exactNaturalBaseline':not differences,'exactDifferenceCount':len(differences),'sampler83Programs':12,'native97Invocations':len(native97),'norm98Enabled':a.norm98,'combinedCoverage':coverage,'scope':'twelve bounded natural tasks; no statistical equivalence claim'}
else:
 assert a.baseline_effect is not None
 for key in ['GENERATION_TRACE','EFFECT_TORCH_COMPILE_DIAGNOSTICS_PATH','EFFECT_TORCH_CUPTI_WINDOW','CUDA_INJECTION64_PATH']:env.pop(key,None)
 target=int(a.stage.removeprefix('timing'));bank=Path('/root/native66-fresh-distinct-v1');pins={}
 for t in [32,128]:
  point=out/f'prompt-{t}';point.mkdir();original=bank/f'prompt-{t}'
  for name in ['benchmark.json','case-plan.json','native66-bank-seal.json']:
   src=original/name;data=src.read_bytes();(point/name).write_bytes(data);pins[str(src)]=sha(src)
  (point/'bank').symlink_to(original/'bank',target_is_directory=True)
  for case in load(original/'case-plan.json')['cases']:
   src=original/'bank'/f"prompt-{t}-seed-{case['seed']}"/'manifest.json';pins[str(src)]=sha(src)
 for kind in ['manifest','bank']:run(['python3',str(here/'bank-guard.py'),kind,str(repo),str(out)])
 historical_vllm=Path(f'/root/native-bf16-87-timing{target}-v1/prompt-{target}/vllm-current-v2.jsonl');vllm=historical_vllm;pins.update({str(f):sha(f) for f in [a.baseline_effect,historical_vllm]})
 run(['bash',str(here/'run-distinct-replay-target.sh'),'effect',str(target),str(out),'combined97-100-101-release-v1'])
 if a.refresh_vllm:
  # The Effect process has exited. The same guarded script validates the exact
  # seven-case inventory again and uses the accepted patched vLLM policy.
  run(['bash',str(here/'run-distinct-replay-target.sh'),'vllm',str(target),str(out),'combined97-100-101-release-v1'])
  vllm=out/f'prompt-{target}/vllm-combined97-100-101-release-v1.jsonl'
  pins[str(vllm)]=sha(vllm)
 assert not (out/'compile-diagnostics.jsonl').exists()
 candidate=out/f'prompt-{target}/effect-combined97-100-101-release-v1.jsonl'
 for filename,command in [('comparison-vs-current-best.json',['python3',str(here/'compare-same-addon.py'),str(a.baseline_effect),str(candidate)]),('comparison-vs-vllm.json',['python3',str(repo/'packages/bench/diffusion-gemma/compare-generation.py'),str(candidate),str(vllm)])]:
  with (out/filename).open('x') as output:run(command,output)
 with (out/'comparison-vs-historical-vllm.json').open('x') as output:run(['python3',str(repo/'packages/bench/diffusion-gemma/compare-generation.py'),str(candidate),str(historical_vllm)],output)
 timing={}
 for name,path in [('combined97_100_101',candidate),('currentBestControl',a.baseline_effect),('vllm',vllm),('historicalVllm',historical_vllm)]:
  rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()];assert len(rows)==5 and sorted(r['run'] for r in rows)==list(range(5));values=[r['elapsedMilliseconds'] for r in sorted(rows,key=lambda r:r['run'])];timing[name]={'source':str(path),'milliseconds':values,'medianMs':statistics.median(values)}
 assessment={'status':'timing-screen-complete','timing':timing,'vsCurrentBestPercent':100*(timing['combined97_100_101']['medianMs']/timing['currentBestControl']['medianMs']-1),'vsVllmPercent':100*(timing['combined97_100_101']['medianMs']/timing['vllm']['medianMs']-1),'freshVllmControl':a.refresh_vllm,'beatsFreshMatchedVllmMedian':a.refresh_vllm and timing['combined97_100_101']['medianMs']<timing['vllm']['medianMs'],'acceptanceRequiresBothTargets':True,'scope':'same sealed seven-case bank; actual model/sampler/prefill/full terminal commit, sequential processes; acceptance requires both targets beat fresh controls'}
for name,digest in pins.items():assert sha(Path(name))==digest,name
(out/'selected-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');print(json.dumps(assessment))
