"""Exact natural generation comparison; no timing fields compared."""
import json,sys
from pathlib import Path
FIELDS=['engine','measurementMode','taskFixtureSha256','model','generation','deployment','promptTokenIds','requestSeeds','generatedTokenIds','generatedTokensPerRequest','refinementsPerRequest','blocksPerRequest','finishReasons','generationTrace']
def read(path):
 rows=[json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]
 result={tuple(r['promptIds']):r for r in rows}
 assert len(rows)==len(result)==12
 assert all(r['naturalTaskSmoke'] and r['engine']=='effect-torch' and r['requestedOutputTokens']==64 for r in rows)
 return result
def compare(left,right):
 assert left.keys()==right.keys()
 for k in left:
  for field in FIELDS:assert field in left[k] and field in right[k] and left[k][field]==right[k][field],(k,field)
 return {'status':'passed','tasks':12,'exactFields':FIELDS}
if __name__=='__main__':print(json.dumps(compare(read(sys.argv[1]),read(sys.argv[2])),indent=2))
