import { Diffusion, Runtime, Tensor } from "@effect-torch/core"
import * as BackendCpu from "@effect-torch/backend-cpu"
import { Effect, Exit } from "effect"
import assert from "node:assert/strict"
import { includeFinalCommit, replayArtifact, type ReplayManifest } from "./controlled-replay97.ts"

await Effect.runPromise(Effect.scoped(Effect.gen(function*() {
  const runtime = yield* Runtime.Runtime
  const [canonical] = yield* Effect.acquireRelease(Tensor.compute([yield* Tensor.full([1], 99)]), Tensor.clearAll)
  const processor = yield* Tensor.freezeProgram([yield* Tensor.full([1], 1), yield* Tensor.full([1], 2)])
  const returned: Array<Tensor.Concrete> = []
  let calls = 0
  const prefix = { tokenCount: 1, bytes: 0 } as Diffusion.Prefix
  const artifact: Diffusion.Artifact = {
    dtype: "f32", predictionDtype: "f32", vocabSize: 4, canvasLength: 1, maxPositions: 16,
    generate: () => Effect.die("original generate unreachable"),
    encode: () => Effect.succeed(prefix), commit: () => Effect.succeed(prefix), release: () => Effect.void,
    inspect: () => Effect.die("inspect unreachable"), score: () => Effect.die("score unreachable"),
    evaluate: () => Effect.die("ordinary evaluate must not execute"),
    evaluateProcessed: (_prefix, canvas, prediction) => Effect.gen(function*() {
      assert.deepEqual(Array.from(canvas), [calls % 2])
      if (calls % 2 === 1) {
        assert.equal(prediction._tag, "Refinement")
        if (prediction._tag === "Refinement") assert.equal(prediction.logits, canonical)
      }
      calls++
      const [device] = yield* Tensor.compute([yield* Tensor.full([1], calls)])
      returned.push(device!)
      return { device: device!, host: Float32Array.of(0.5) }
    })
  }
  const manifest: ReplayManifest = {
    schema: "effect-torch-controlled-trajectory-v1", label: "controlled-trajectory-replay-not-natural-generation",
    request: { promptTokenIds: [1], seed: 17, maxNewTokens: 1 }, committedCanvasTokenIds: [2], outputTokenIds: [2],
    steps: [0, 1].map((index) => ({ index, block: 0, step: index, rngDraw: index, temperature: 1, done: index === 1,
      canvasTokenIds: [index], postCanvasTokenIds: [index + 1], draftTokenIds: [2],
      feedbackInput: index === 0 ? null : { file: "canonical", sha256: "a".repeat(64), dtype: "BF16", shape: [1] }
    }))
  }
  const counts = { prefill: 0, reads: 0, samplers: 0, commits: 0 }
  const controlled = replayArtifact(includeFinalCommit(artifact, counts), manifest, new Map([["canonical", canonical!]]))
  let pages = 0
  const options: Diffusion.GenerationRequest<number, number> = {
    prompt: Uint32Array.of(1), maxNewTokens: 1, outputLimit: "exact",
    initialize: () => Effect.succeed({ value: { canvas: Uint32Array.of(0), feedback: { _tag: "Initial" } }, release: Effect.void }),
    process: () => Effect.die("ordinary sampler must not execute"),
    processed: { processor, scalar: () => 1, decode: (host) => host[0]! },
    policy: { canvasLength: 1, maxSteps: 2, start: () => 0,
      refine: (input) => { assert.equal(input.prediction, 0.5); return Effect.succeed({ state: 0, canvas: input.canvas, draft: Uint32Array.of(0), done: false }) },
      finish: (draft) => ({ tokens: draft, stop: true }) },
    onPage: (tokens) => Effect.sync(() => { assert.deepEqual(Array.from(tokens), [2]); pages++ })
  }
  for (let i = 0; i < 2; i++) {
    const result = yield* controlled.generate({ ...options, processed: { ...options.processed! } })
    assert.equal(result.refinements, 2)
  }
  assert.deepEqual(counts, { prefill: 2, reads: 4, samplers: 4, commits: 2 })
  assert.equal(pages, 2)
  assert.deepEqual(yield* Tensor.toNumberArray(canonical!), [99])
  for (const value of returned) assert.equal((yield* Effect.flip(runtime.readback(value))).reason, "invalid-handle")
  const exit = yield* Effect.exit(controlled.generate({ ...options, processed: { ...options.processed!, decode: () => { throw new Error("decode failure") } } }))
  assert(Exit.isFailure(exit))
  assert.equal((yield* Effect.flip(runtime.readback(returned.at(-1)!))).reason, "invalid-handle")
  assert.deepEqual(yield* Tensor.toNumberArray(canonical!), [99])
  process.stdout.write(JSON.stringify({ status: "passed", processedCalls: calls, successfulRequests: 2, canonicalBorrowPreserved: true,
    computedOutputsReleased: returned.length, terminalCommits: counts.commits, failedDecodeReleased: true }) + "\n")
})).pipe(Effect.provide(BackendCpu.layer)))
