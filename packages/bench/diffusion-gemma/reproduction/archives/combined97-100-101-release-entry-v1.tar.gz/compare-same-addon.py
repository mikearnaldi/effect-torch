#!/usr/bin/env python3
import json, math, sys
from pathlib import Path
KEYS = ("targetPromptTokens", "requestedOutputTokens", "concurrency", "run")
def read(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        row = json.loads(line)
        key = tuple(row[k] for k in KEYS)
        assert key not in result, "duplicate run"
        assert all(type(x) is int for x in key) and all(x > 0 for x in key[:3]) and key[3] >= 0
        assert row["engine"] == "effect-torch" and row["measurementMode"] == "timing"
        assert "measurementWindow" not in row and "measurementWindowWallNs" not in row, "unexpected profiler measurement window; review required"
        assert type(row["elapsedMilliseconds"]) in (float, int) and math.isfinite(row["elapsedMilliseconds"]) and row["elapsedMilliseconds"] > 0
        assert isinstance(row["timestamp"], str) and row["timestamp"]
        result[key] = {k:v for k,v in row.items() if k not in ("timestamp", "elapsedMilliseconds")}
    assert result, "empty rows"
    for point in {key[:3] for key in result}:
        assert {key[3] for key in result if key[:3] == point} == set(range(5))
    return result
left, right = map(read, sys.argv[1:])
assert left.keys() == right.keys(), "run keys differ"
differences = [{"run": key, "field": field} for key in sorted(left) for field in sorted(left[key].keys() | right[key].keys()) if field not in left[key] or field not in right[key] or left[key][field] != right[key][field]]
print(json.dumps({"matched": not differences, "ignoredFields": ["timestamp", "elapsedMilliseconds"], "differences": differences}, indent=2))
sys.exit(bool(differences))
