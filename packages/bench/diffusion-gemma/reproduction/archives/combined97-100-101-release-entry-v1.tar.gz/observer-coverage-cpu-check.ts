import * as fs from "node:fs"
import vm from "node:vm"
const source = fs.readFileSync(new URL("./natural93-effect.ts", import.meta.url), "utf8")
const start = source.indexOf("const requireCombinedCoverage101 =")
const end = source.indexOf("const compileDiagnosticsPath93", start)
const js = source.slice(start, end).replace(": Runtime.CompileRequest", "").replace(": Runtime.ExecutableHandle", "").replace(": string", "") + "\nglobalThis.check = requireCombinedCoverage101"
const sandbox = { process: { env: {} as Record<string, string> }, check: undefined as unknown }
vm.runInNewContext(js, sandbox)
const check = sandbox.check as (request: unknown, executable: unknown) => void
let passed = 0
for (const enabled of [false, true]) for (const access of ["Append", "ReadOnly"]) for (const width of [16, 64, 256, 512]) {
  sandbox.process.env = enabled ? { EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY: "/root/triton-normalization98-screen-v1" } : {}
  const norm = width === 256 ? 25 : 0
  const norm98 = enabled ? (access === "ReadOnly" ? 30 : 29) : 0
  const request = { roots: [{ shape: [1, width, 2816] }], state: { access } }
  const counts = { fused_moe75: 30, triton_normrope101: norm, normrope101_output: norm * 2, triton_norm98_entrance: norm98, triton_norm98_tail: norm98 }
  const executable = (values: Record<string, number>) => ({ diagnostics: { instructions: Object.entries(values).map(([kind, count]) => ({ kind, count })) } })
  check(request, executable(counts)); passed++
  for (const bad of [{ ...counts, triton_normrope101: norm + 1 }, { ...counts, normrope101_output: norm * 2 + 1 }, { ...counts, triton_norm98_tail: norm98 + 1 }, { ...counts, et_ffn_next_norm63_bf16: 1 }]) {
    let rejected = false
    try { check(request, executable(bad)) } catch { rejected = true }
    if (!rejected) throw new Error("compile coverage accepted malformed program")
    passed++
  }
}
if (source.indexOf("requireCombinedCoverage101(request, executable)") < source.indexOf('event: "compile-diagnostics"')) throw new Error("diagnostics must be persisted before rejection")
console.log(JSON.stringify({ status: "passed", cases: passed, includes: "norm98 off/on, Append/ReadOnly, T16/64/256/512, wrong groups/aliases/tail/fallback rejected" }))
