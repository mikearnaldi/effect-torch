"""Guarded combined97+100+101 full-model evaluation. Root owns all remote/GPU execution."""
import argparse,fcntl,hashlib,json,os,shlex,signal,statistics,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage',choices=['natural','timing32','timing128']);p.add_argument('--quality',type=Path);p.add_argument('--baseline-effect',type=Path);p.add_argument('--baseline-natural',type=Path,default=Path('/root/literal89-plus66-natural-v1/candidate-effect.jsonl'));p.add_argument('--output',type=Path,required=True);p.add_argument('--build',type=Path,default=Path('/root/combined97-100-101-release-build-v1'));p.add_argument('--norm98',action='store_true');p.add_argument('--refresh-vllm',action='store_true');p.add_argument('--preflight',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;repo=Path('/root/effect-torch');out=a.output;assert out.is_absolute()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
manifest=load(a.build/'source-v1-manifest.json');receipt=load(a.build/'build-receipt.json');hardware=load(a.build/'hardware/assessment.json')
assert manifest['archiveSha256']=='54979d50b5cb2e5ae68ece16540d26150957210dc42c4cbfb74508067a3e337e'
assert receipt['sourceArchiveSha256']==hardware['sourceArchiveSha256']==manifest['archiveSha256']
assert receipt['profile']==hardware['profile']=='release'
expected_profile={'optLevel':3,'lto':True,'codegenUnits':1,'debugAssertions':False,'overflowChecks':False,'debug':0,'incremental':False,'panic':'unwind'}
assert receipt['buildProfile']==hardware['buildProfile']==expected_profile
assert receipt['artifactSubdirectory']==hardware['artifactSubdirectory']=='x86_64-unknown-linux-gnu/release'
assert '--release' in receipt['buildCommand']
assert hardware['status']=='passed' and hardware['candidateSha256']==receipt['sha256']=='fab05c99fb5158489345af782f1fdbc53f8630e0ad723dda6e86b399e91a8be4'
assert {'host','chain97-parity','normrope101-loader-parity','normrope101-compiled-lifecycle','normrope101-lazy-kv-schedule','normrope101-actual-model-tables-kv','softmax100-loader-parity','softmax100-compiled-lifecycle'}.issubset(hardware['checks'])
candidate=a.build/'combined97-100-101-release-v1.node';assert Path(receipt['candidate'])==candidate
baseline={
 'packages/backend-cuda/dist/internal/effect-torch-backend-cuda.linux-x64-gnu.node':'bdb5d1e21325b747fc989514bb2fad14b38796a1d1a8af3b73ee299303968d8a',
 'packages/backend-cuda/src/internal/adapter.ts':'8159fd27721c4c3029d76c4b0ae27f96c6300db827c94522fd507c1f5e17186b',
 'packages/backend-cuda/src/internal/native-addon.d.ts':'fec3bb5e08fa61c7c9e65b58cd924151873e9951e9bbc64c495ee397636844fa',
 'packages/models/src/DiffusionGemma.ts':'11bd30b0253e942652a89bfac0d7020f5030bf15e3b8c9c82b29997c7a2d0b27',
 'packages/core/src/Runtime.ts':'7e21777bf0d1a473bde2f8b4cf6503ec0068ab37a4fccb0907611705e2713c3f',
 'packages/core/src/Tensor.ts':'613941dc68a720b08f99e26451d2964ba3b52f54f6cb38803463f6e417446efa',
 'packages/core/src/Diffusion.ts':'17fb5e0da33600125fb871cbc6de7fb814eea8f05f3320dd48a610ad89da39d8',
 'packages/bench/diffusion-gemma/controlled-replay.ts':'e65ba98584e31ac722bb6556a17af1eae6cc94323307b11ccbf76680f10fcc58'}
replacement={name:(candidate if name.endswith('.node') else a.build/'source-v1'/name) for name in baseline}
replacement['packages/bench/diffusion-gemma/controlled-replay.ts']=here/'controlled-replay97.ts'
additions={name:a.build/'source-v1'/name for name in ['packages/backend-cuda/src/internal/chain96.ts','packages/backend-cuda/src/internal/chain97.ts','packages/backend-cuda/src/internal/requestRng99.ts']}
additions['packages/bench/diffusion-gemma/natural93-effect.ts']=here/'natural93-effect.ts'
candidate_hashes={name:sha(path) for name,path in replacement.items()};addition_hashes={name:sha(path) for name,path in additions.items()}
assert candidate_hashes[next(iter(baseline))]==receipt['sha256']
assert all(candidate_hashes[n]==manifest['files'][n] for n in baseline if n in manifest['files'])
guards=load(here/'artifact-guards.json');source_guards=load(here/'source-guards.json')
guards.update(source_guards['externalFiles']);guards.update({str(repo/n):h for n,h in source_guards['harnessFiles'].items() if n not in baseline});guards.update({str(here/n):h for n,h in load(here/'runner-hashes.json').items()})
guards[str(candidate)]=receipt['sha256'];guards[str(a.build/'source-v1.tar.gz')]=manifest['archiveSha256']
guards.update({str(a.build/'source-v1'/n):h for n,h in manifest['files'].items()})
for name in ['source-v1-manifest.json','build-receipt.json','hardware/assessment.json']:guards[str(a.build/name)]=sha(a.build/name)
# Model and adapter are transactional replacements; other shared TS dependency
# pins come from the independently reviewed policy90 driver environment.
for n,h in load(here/'dependency-pins.json').items():
 if n not in baseline:guards[str(repo/n)]=h
# Preserve the accepted validator; only this reviewed two-assertion source
# difference overrides the diagnostic's local dependency pin.
override=load(here/'dependency-override.json')
assert override['path']=='packages/bench/diffusion-gemma/controlled-replay-validation.ts'
assert load(here/'dependency-pins.json')[override['path']]==override['diagnosticManifestSha256']=='52d53f97522729b42bceaafabe31e0b7d58d5feb5eb77a8fe4c349d24e6fc839'
assert override['executedAcceptedSha256']=='7d8db49ee6c9e06fe44c6ed94731e7b08027eb51b1b58b941ebbd952b5239a5d'
assert sha(here/override['acceptedSourceEvidence'])==override['executedAcceptedSha256']
guards[str(repo/override['path'])]=override['executedAcceptedSha256']
for directory,pins in [('/root/triton-normrope101-fulltables-screen-v2','normrope101-ptx-pins.json'),('/root/triton-softmax100-screen-v1','softmax100-ptx-pins.json')]:
 for name,digest in load(here/pins).items():guards[str(Path(directory)/name)]=digest
if a.norm98:
 for name,digest in load(here/'norm98-ptx-pins.json').items():guards[str(Path('/root/triton-normalization98-screen-v1')/name)]=digest
for path in [a.baseline_natural]+([a.baseline_effect] if a.baseline_effect else []):guards[str(path)]=sha(path)
if a.stage!='natural':
 assert a.quality is not None and a.baseline_effect is not None,'timing requires passed quality and explicit currentbest baseline'
 quality=load(a.quality/'assessment.json');quality_provenance=load(a.quality/'provenance.json')
 assert quality['status']=='natural-quality-passed' and quality['summary']['candidate-effect']=={'passed':12,'total':12}
 assert quality_provenance['flags']['EFFECT_TORCH_DIFFUSION_PROCESSED_EVALUATION97']=='1'
 assert quality_provenance['profile']=='release' and quality_provenance['buildProfile']==expected_profile
 assert ('EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY' in quality_provenance['flags'])==a.norm98,'quality/timing norm98 flags differ'
 assert quality_provenance['flags']['EFFECT_TORCH_CUDA_FFN_NEXT_NORM63']==('1' if a.norm98 else '0')
 if a.norm98:assert quality_provenance['flags']['EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY']=='/root/triton-normalization98-screen-v1'
 assert quality_provenance['flags']['EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY']=='/root/triton-normrope101-fulltables-screen-v2'
 assert quality_provenance['flags']['EFFECT_TORCH_CUDA_TRITON_SOFTMAX100_DIRECTORY']=='/root/triton-softmax100-screen-v1'
 assert quality_provenance['candidate']==candidate_hashes and quality_provenance['buildArchiveSha256']==manifest['archiveSha256']
 for path in [a.quality/'assessment.json',a.quality/'provenance.json']:guards[str(path)]=sha(path)
def fixed_guard():
 for name,digest in guards.items():assert sha(Path(name))==digest,name
# Bank manifest/seal inventory checked once; selected feedback bytes are hashed
# by the guarded driver preload before any quality or timing work.
def installed_guard(expected):
 for name,digest in expected.items():assert not (repo/name).is_symlink() and sha(repo/name)==digest,name
def replace(path,data,expected):
 assert not path.is_symlink() and sha(path)==expected,f'unknown concurrent file: {path}'
 fd,temporary=tempfile.mkstemp(prefix='.chain97-',dir=path.parent)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(temporary,path.stat().st_mode&0o777)
  assert sha(path)==expected,f'concurrent mutation: {path}'
  os.replace(temporary,path)
 finally:
  if os.path.exists(temporary):os.unlink(temporary)
def publish(path,data):
 assert not path.exists() and not path.is_symlink(),f'create-only private file exists: {path}'
 fd,temporary=tempfile.mkstemp(prefix='.chain97-new-',dir=path.parent)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.link(temporary,path) # Atomic no-overwrite creation.
 finally:
  if os.path.exists(temporary):os.unlink(temporary)
fixed_guard();installed_guard(baseline)
for name in additions:assert not (repo/name).exists() and not (repo/name).is_symlink(),name
assert not out.exists(),'fresh output required'
if a.preflight:print('CPU guards passed; no GPU query, file replacement, or process launch');raise SystemExit(0)
lock=(repo/'.literal89-swap.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
installed_guard(baseline)
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip(),'GPU occupied'
out.mkdir();snapshots=out/'originals';snapshots.mkdir();originals={name:(repo/name).read_bytes() for name in baseline}
for name,data in originals.items():(snapshots/name.replace('/','__')).write_bytes(data)
env={k:v for k,v in os.environ.items() if not k.startswith(('EFFECT_TORCH_','CUPTI_','REPLAY_','DIFFUSION_','ET_VLLM_','CHAIN96_','CHAIN97_')) and k not in ['CUDA_INJECTION64_PATH','PYTHONPATH','MANIFEST','OUTPUT','GENERATION_TRACE','NATURAL_TASKS75']}
flags={
 'EFFECT_TORCH_CUDA_RMS_VECTOR_LOADS':'1','EFFECT_TORCH_CUDA_RMS_STATIC2816':'1',
 'EFFECT_TORCH_CUDA_FFN_NEXT_NORM63':'0','EFFECT_TORCH_CUDA_ATTN_FFN_ENTRANCE':'1',
 'EFFECT_TORCH_CUDA_WHOLE_READ71':'0','EFFECT_TORCH_CUDA_ROTARY_REUSE66':'1',
 'EFFECT_TORCH_CUDA_LITERAL89':'1','EFFECT_TORCH_CUDA_LITERAL_LEAF88':'0',
 'EFFECT_TORCH_DIFFUSION_SCALAR_TEMPERATURE93':'1','DIFFUSION_FUSED_READOUT':'1',
 'EFFECT_TORCH_CUDA_SAMPLER83':'1','EFFECT_TORCH_CUDA_ATTENTION82_BF16_IO':'1',
 'EFFECT_TORCH_CUDA_RELAXED_NORM76':'1','EFFECT_TORCH_CUDA_PACKED_PROJECTION77':'1',
 'EFFECT_TORCH_CUDA_RNG_ARG80':'1','EFFECT_TORCH_CUDA_RELAXED_ENTROPY81':'1',
 'EFFECT_TORCH_CUDA_FUSED_MOE75':'1','EFFECT_TORCH_CUDA_FUSED_MOE75_SO':'/root/expert-flashinfer73-v2/libexpert-flashinfer73.so',
 'EFFECT_TORCH_CUDA_FUSED_MOE75_GEMM1':'1','EFFECT_TORCH_CUDA_FUSED_MOE75_GEMM2':'1',
 'EFFECT_TORCH_CUDA_ATTENTION75_DIRECTORY':'/root/combined87-build-v3/ptx-abi2',
 'EFFECT_TORCH_DIFFUSION_PROCESSED_EVALUATION97':'1',
 'EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY':'/root/triton-normrope101-fulltables-screen-v2',
 'EFFECT_TORCH_CUDA_TRITON_SOFTMAX100_DIRECTORY':'/root/triton-softmax100-screen-v1',
 'EFFECT_TORCH_CUDA_VNORM_STORE':'0','EFFECT_TORCH_CUDA_BF16_SOFTMAX':'1'}
if a.norm98:
 flags.update(EFFECT_TORCH_CUDA_TRITON_NORM98_DIRECTORY='/root/triton-normalization98-screen-v1',EFFECT_TORCH_CUDA_FFN_NEXT_NORM63='1')
command=['python3',str(here/'stage.py'),a.stage,'--output',str(out),'--baseline-natural',str(a.baseline_natural)]
if a.baseline_effect:command+=['--baseline-effect',str(a.baseline_effect)]
if a.norm98:command+=['--norm98']
if a.refresh_vllm:
 assert a.stage!='natural','fresh control option requires timing stage'
 command+=['--refresh-vllm']
shell='set -euo pipefail\nsource '+shlex.quote(str(here/'common-env.sh'))+'\n'+''.join('export '+k+'='+shlex.quote(v)+'\n' for k,v in flags.items())+'exec '+shlex.join(command)
(out/'provenance.json').write_text(json.dumps(dict(buildProfile=receipt['buildProfile'],profile=receipt['profile'],artifactSubdirectory=receipt['artifactSubdirectory'],baseline=baseline,candidate=candidate_hashes,added=addition_hashes,buildArchiveSha256=manifest['archiveSha256'],flags=flags,command=command,guardedFiles=guards,dependencyOverride=override,scope='combined97+100+101 fullmodel quality and matched canonical-bank timing; norm98explicitopt-in(defaultOFF), request-private scalar sampler'),indent=2)+'\n')
child=None;changed=[];created=[];code=None
def interrupted(signum,frame):raise KeyboardInterrupt(str(signum))
for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
try:
 # All private imports and natural observer exist before the adapter replacement is visible.
 for name,source in additions.items():
  old_mask=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
  try:publish(repo/name,source.read_bytes());created.append(name)
  finally:signal.pthread_sigmask(signal.SIG_SETMASK,old_mask)
 for name,source in replacement.items():
  old_mask=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
  try:replace(repo/name,source.read_bytes(),baseline[name]);changed.append(name)
  finally:signal.pthread_sigmask(signal.SIG_SETMASK,old_mask)
 installed_guard({**candidate_hashes,**addition_hashes});fixed_guard()
 with (out/'run.log').open('x') as log:
  child=subprocess.Popen(['bash','-c',shell],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);code=child.wait()
 installed_guard({**candidate_hashes,**addition_hashes});fixed_guard()
 assert code==0,f'model diagnostic failed {code}'
finally:
 for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,signal.SIG_IGN)
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 errors=[]
 for name in reversed(changed):
  try:replace(repo/name,originals[name],candidate_hashes[name])
  except Exception as error:errors.append(str(error))
 for name in reversed(created):
  path=repo/name
  if path.exists() and not path.is_symlink() and sha(path)==addition_hashes[name]:path.unlink()
  else:errors.append('private file changed; retained: '+name)
 for name,digest in baseline.items():
  if (repo/name).is_symlink() or not (repo/name).exists() or sha(repo/name)!=digest:errors.append('baseline not restored: '+name)
 (out/'restored.json').write_text(json.dumps(dict(restored=not errors,baseline=baseline,addedFilesRemoved=all(not (repo/n).exists() for n in additions),exitCode=code,errors=errors),indent=2)+'\n')
 assert not errors,errors
fixed_guard()
print(json.dumps(load(out/'assessment.json')))
