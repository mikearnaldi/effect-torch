"""Strict twelve-task CPU smoke scorer; no timing or statistical equivalence claim."""
import argparse
import hashlib
import json
from pathlib import Path


def score_text(task,text):
    if task['scorer']=='trim-exact':return text.strip()==task['expected']
    if task['scorer']=='json-equal':
        try:return json.loads(text)==task['expected']
        except (ValueError,TypeError):return False
    raise ValueError('unknown frozen scorer')


def empty_thought_header(tokenizer):
    """The model chat protocol's channel separator immediately closes thought.

    See diffusiongemma/chat_template.jinja and DiffusionGemma's canvasText.
    Prove the complete token sequence using this run's hashed tokenizer; plain
    text beginning with "thought" is never sufficient to remove content.
    """
    literal='<|channel>thought\n<channel|>'
    ids=tokenizer.encode(literal,add_special_tokens=False).ids
    opening=tokenizer.token_to_id('<|channel>')
    closing=tokenizer.token_to_id('<channel|>')
    if (opening is None or closing is None or opening==closing or len(ids)<3
            or ids[0]!=opening or ids[-1]!=closing
            or tokenizer.decode(ids,skip_special_tokens=False)!=literal):
        raise ValueError('tokenizer cannot prove empty thought channel header')
    return ids


def answer_view(tokenizer,token_ids,header):
    removed=len(header) if token_ids[:len(header)]==header else 0
    answer_ids=token_ids[removed:]
    return {'text':tokenizer.decode(token_ids,skip_special_tokens=True),
            'tokenIds':token_ids,
            'answerText':tokenizer.decode(answer_ids,skip_special_tokens=True),
            'answerTokenIds':answer_ids,
            'answerExtraction':{'policy':'exact-leading-empty-thought-channel-v1',
                                'removedTokens':removed,
                                'removedTokenIds':token_ids[:removed]}}


def read_run(path,tasks,fixture_hash):
    rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    records={}
    for row in rows:
        if row.get('measurementMode')!='natural-task-smoke-no-performance-claim' or row.get('naturalTaskSmoke') is not True:
            raise ValueError('not a natural75 smoke record')
        if row.get('taskFixtureSha256')!=fixture_hash or 'replayOutput' in row:
            raise ValueError('fixture differs or replay outputs supplied')
        if row['concurrency']!=1 or row['run']!=0 or row['requestedOutputTokens']!=64:
            raise ValueError('unexpected natural75 request matrix')
        task_id,=row['promptIds']
        if task_id not in tasks or task_id in records:raise ValueError('missing/duplicate/unknown task')
        if len(row['generatedTokenIds'])!=1 or len(row['requestSeeds'])!=1:raise ValueError('invalid single request record')
        counts=row.get('refinementsPerRequest')
        if counts is None or len(counts)!=1 or not isinstance(counts[0],int) or counts[0]<=0:
            raise ValueError('missing natural refinement evidence; enable diagnostic tracing')
        if row['engine']=='vllm':
            overlay=row.get('experimentalOverlay') or {}
            if not all(overlay.get('patchScope',{}).get(key) is True for key in ['priorHistory','sharedRng','samplerMath']):
                raise ValueError('vLLM policy/RNG provenance absent')
            if overlay.get('patchScope',{}).get('controlledReplay'):
                raise ValueError('vLLM controlled replay overlay cannot score natural quality')
            attestations=row.get('overlayImportAttestations')
            if not attestations or any(item['sha256']!=overlay['patchedSha256'] for item in attestations):
                raise ValueError('missing/mismatched vLLM overlay import attestation')
        records[task_id]=row
    if set(records)!=set(tasks):raise ValueError('expected exactly all twelve frozen tasks')
    return records


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--fixture',type=Path,default=Path(__file__).with_name('natural-tasks.json'))
    parser.add_argument('--tokenizer',type=Path,required=True)
    parser.add_argument('--run',action='append',required=True,help='label=natural75.jsonl')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    from tokenizers import Tokenizer
    raw=args.fixture.read_bytes();fixture=json.loads(raw);tasks={task['id']:task for task in fixture['tasks']}
    if len(tasks)!=12:raise ValueError('requires twelve frozen tasks')
    fixture_hash=hashlib.sha256(raw).hexdigest();tokenizer_hash=hashlib.sha256(args.tokenizer.read_bytes()).hexdigest()
    tokenizer=Tokenizer.from_file(str(args.tokenizer));header=empty_thought_header(tokenizer);runs={}
    for item in args.run:
        label,path=item.split('=',1)
        if label in runs:raise ValueError('duplicate run label')
        runs[label]=read_run(Path(path),tasks,fixture_hash)
    if len(runs)<2:raise ValueError('supply at least two paired natural runs')
    results=[]
    for task_id,task in tasks.items():
        baseline=None;scored={}
        for label,run in runs.items():
            row=run[task_id]
            if row['model']['tokenizerSha256']!=tokenizer_hash:raise ValueError('tokenizer hash differs')
            contract={key:row[key] for key in ['promptTokenIds','requestSeeds','generation','requestedOutputTokens','model']}
            if baseline is None:baseline=contract
            elif contract!=baseline:raise ValueError('paired input/seed/generation/model contracts differ')
            answer=answer_view(tokenizer,row['generatedTokenIds'][0],header)
            scored[label]={'passed':score_text(task,answer['answerText']),**answer,
                           'refinements':row['refinementsPerRequest'][0],
                           'finishReasons':row.get('finishReasons'),'generatedTokens':len(row['generatedTokenIds'][0])}
        results.append({'task':task_id,'expected':task['expected'],'scorer':task['scorer'],'runs':scored})
    summary={label:{'passed':sum(row['runs'][label]['passed'] for row in results),'total':12} for label in runs}
    baseline_label=next(iter(runs))
    regressions={label:[row['task'] for row in results if row['runs'][baseline_label]['passed'] and not row['runs'][label]['passed']]
                 for label in runs if label!=baseline_label}
    with args.output.open('x') as file:
        json.dump({'status':'bounded-natural-smoke-scored','claim':'no statistical quality equivalence or latency claim',
                   'answerExtractionPolicy':'exact-leading-empty-thought-channel-v1',
                   'emptyThoughtHeaderTokenIds':header,'tokenizerSha256':tokenizer_hash,
                   'scorerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   'fixtureSha256':fixture_hash,'summary':summary,'baselineLabel':baseline_label,
                   'newFailuresAgainstBaseline':regressions,'tasks':results},file,indent=2);file.write('\n')

if __name__=='__main__':main()
