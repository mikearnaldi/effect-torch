"""CPU-only exercise of exact timing-stage AST; subprocess calls are recorded fakes."""
import ast, hashlib, json, statistics, tempfile
from pathlib import Path
from types import SimpleNamespace
here=Path(__file__).resolve().parent
tree=ast.parse((here/'stage.py').read_text())
branch=next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="a.stage == 'natural'")
code=compile(ast.Module(body=branch.orelse,type_ignores=[]),'exact-timing-stage','exec')
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(ms):return ''.join(json.dumps({'run':i,'elapsedMilliseconds':ms+i})+'\n' for i in range(5))
results=[]
for fresh in [False,True]:
 with tempfile.TemporaryDirectory(prefix='combined-fresh-control-check-') as directory:
  root=Path(directory);out=root/'output';out.mkdir();repo=root/'effect-torch';repo.mkdir()
  baseline=root/'baseline.jsonl';baseline.write_text(rows(105))
  for target in [32,128]:
   point=root/'native66-fresh-distinct-v1'/f'prompt-{target}';point.mkdir(parents=True)
   (point/'benchmark.json').write_text('{}');cases=[{'seed':i,'run':i-2} for i in range(7)]
   (point/'case-plan.json').write_text(json.dumps({'cases':cases}));(point/'native66-bank-seal.json').write_text('[]')
   for case in cases:
    bank=point/'bank'/f"prompt-{target}-seed-{case['seed']}";bank.mkdir(parents=True);(bank/'manifest.json').write_text('{}')
  historical=root/'native-bf16-87-timing32-v1/prompt-32/vllm-current-v2.jsonl';historical.parent.mkdir(parents=True);historical.write_text(rows(90))
  def remap(path):
   text=str(path)
   return root/text.removeprefix('/root/') if text.startswith('/root/') else Path(path)
  launches=[];comparisons=[]
  def run(command,output=None):
   if 'run-distinct-replay-target.sh' in str(command[1]):
    _,_,arm,target,output_root,tag=command;launches.append((arm,target,output_root,tag))
    (Path(output_root)/f'prompt-{target}'/f'{arm}-{tag}.jsonl').write_text(rows(100 if arm=='effect' else 110))
   elif str(command[1]).endswith('compare-generation.py'):
    comparisons.append(command[2:]);output.write('{}\n')
   elif output is not None:output.write('{}\n')
  scope={'a':SimpleNamespace(baseline_effect=baseline,refresh_vllm=fresh,stage='timing32'),'env':{},'out':out,'repo':repo,'here':here,
   'Path':remap,'pins':{},'load':load,'sha':sha,'run':run,'json':json,'statistics':statistics}
  exec(code,scope)
  assert [r[0] for r in launches]==(['effect','vllm'] if fresh else ['effect'])
  assert all(r[1:] == launches[0][1:] for r in launches)
  assessment=scope['assessment'];assert assessment['freshVllmControl']==fresh
  assert assessment['beatsFreshMatchedVllmMedian']==fresh
  assert assessment['acceptanceRequiresBothTargets']
  assert assessment['timing']['historicalVllm']['medianMs']==92
  assert assessment['timing']['vllm']['medianMs']==(112 if fresh else 92)
  assert all('effect-combined97-100-101-release-v1.jsonl' in pair[0] for pair in comparisons)
  assert str(historical)==comparisons[-1][1]
  if fresh:assert comparisons[0][1].endswith('/vllm-combined97-100-101-release-v1.jsonl')
  results.append({'refresh':fresh,'launchOrder':[r[0] for r in launches],'sameTargetBankAndTag':True,'effectLeftComparison':True,'historicalPreserved':True})
print(json.dumps({'status':'passed','cases':results}))
