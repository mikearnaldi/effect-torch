#!/usr/bin/env bash
# Run inside the CUDA devbox Nix environment. Invoke one GPU stage at a time.
# prepare/capture/effect/vllm/compare TARGET ABSOLUTE_ROOT [FRESH_OUTPUT_TAG]
set -euo pipefail
stage=${1:?prepare, capture, effect, vllm, or compare}
target=${2:?32 or 128}
run_root=${3:?fresh absolute evidence root}
tag=${4:-v1}
[[ "$target" == 32 || "$target" == 128 ]]
[[ "$run_root" == /* && "$tag" =~ ^[a-zA-Z0-9_-]+$ ]]
cd /root/effect-torch
point=${run_root}/prompt-${target}
export MANIFEST=${point}/benchmark.json
export REPLAY_DIRECTORY=${point}/bank
export REPLAY_TARGETS=${target}
export REPLAY_DISTINCT_SEEDS=1
export REPLAY_PROFILE=0
export MODEL_PATH=${MODEL_PATH:-/root/models/diffusiongemma}
export INITIALIZED_STATE_PATH=${INITIALIZED_STATE_PATH:-/root/oracle-eager-20260930/initialized-state/initialized-rope.safetensors}

if [[ "$stage" == prepare ]]; then
  python3 - "$target" "$point" "${DISTINCT_MANIFEST_SOURCE:-/root/bench-controlled-replay-20260930.json}" <<'PY'
import json, pathlib, sys
target, point, source = int(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
manifest = json.loads(source.read_text())
manifest['matrix'].update(promptTargets=[target], outputTokens=[64], concurrencies=[1], warmupRuns=2, measuredRuns=5)
point.mkdir(parents=True, exist_ok=True)
with (point/'benchmark.json').open('x') as output:
    json.dump(manifest, output, indent=2)
runs = [-1, -2, 0, 1, 2, 3, 4]
plan = {'workload': 'controlled-trajectory-replay', 'seedMode': 'distinct', 'target': target,
        'warmupOrder': [-1, -2], 'measuredOrder': list(range(5)),
        'cases': [{'run': run, 'seed': (manifest['generation']['seed'] + target*101 + 64*17 + 13 + run*7) & 0xffffffff} for run in runs],
        'bankScope': 'one prompt target per GPU process; seven trajectories preloaded before timing'}
with (point/'case-plan.json').open('x') as output:
    json.dump(plan, output, indent=2)
print(json.dumps(plan))
PY
  exit 0
fi
[[ -f "$MANIFEST" && -f "${point}/case-plan.json" ]]
if [[ "$stage" == compare ]]; then
  [[ ! -e "${point}/comparison-${tag}.json" ]]
  python3 packages/bench/diffusion-gemma/compare-generation.py "${point}/effect-${tag}.jsonl" "${point}/vllm-${tag}.jsonl" > "${point}/comparison-${tag}.json"
  cat "${point}/comparison-${tag}.json"
  exit 0
fi
[[ "$stage" == capture || "$stage" == effect || "$stage" == vllm ]]
prefix=${point}/${stage}-${tag}
[[ ! -e "${prefix}.log" && ! -e "${prefix}.jsonl" ]]

if [[ "$stage" == capture ]]; then
  mkdir "$REPLAY_DIRECTORY" # Deliberately refuses an existing/partial bank.
else
  # CPU-only selected manifest inventory; guarded TS preload hashes selected feedback bytes before timing.
  python3 - "$point" <<'PY'
import hashlib, json, pathlib, sys
point = pathlib.Path(sys.argv[1]); plan = json.loads((point/'case-plan.json').read_text())
expected = [point/'bank'/f"prompt-{plan['target']}-seed-{case['seed']}"/'manifest.json' for case in plan['cases']]
assert set((point/'bank').glob('**/manifest.json')) == set(expected), 'bank must contain exactly seven selected cases'
records = []
for case, path in zip(plan['cases'], expected):
    raw = path.read_bytes(); manifest = json.loads(raw); digest = hashlib.sha256(raw).hexdigest()
    assert manifest['request']['seed'] == case['seed']
    assert len(manifest['request']['promptTokenIds']) == plan['target']
    assert manifest['request']['maxNewTokens'] == 64
    records.append({**case, 'manifestSha256': digest, 'refinements': len(manifest['steps'])})
inventory = {'validatedCases': records, 'scope': 'canonical inputs; actual model and sampler remain computed'}
inventory_path = point/'bank-inventory.json'
if inventory_path.exists():
    assert json.loads(inventory_path.read_text()) == inventory, 'bank inventory changed between backend runs'
else:
    with inventory_path.open('x') as output:
        json.dump(inventory, output, indent=2)
print(json.dumps(inventory))
PY
fi

if [[ "$stage" == vllm ]]; then
  export PYTHONPATH=/root/vllm-controlled-replay-v4-20260930
  export ET_VLLM_OVERLAY_MANIFEST=${PYTHONPATH}/manifest.json
  export ET_VLLM_OVERLAY_ATTESTATION=${prefix}-attestation.jsonl
  export ET_VLLM_DECODE_COUNTERS=${prefix}-counters
  export ET_VLLM_REPLAY_DIR=${REPLAY_DIRECTORY}
  export ET_VLLM_REPLAY_DISTINCT_SEEDS=1
  export OUTPUT=${prefix}.jsonl
  exec /root/.cache/effect-torch/vllm-0.24.0/bin/python packages/bench/diffusion-gemma/vllm-direct.py > "${prefix}.log" 2>&1
fi

# Exact validated Effect optimizations. Repeated-route graph caches are disabled.
export EFFECT_TORCH_CUDA_SMALL_MAX=1
export EFFECT_TORCH_CUDA_GROUPED_EXACT=1
export EFFECT_TORCH_CUDA_DENSE_OVERLAP=1
export EFFECT_TORCH_CUDA_WIDE_SUM_FUSION=1
export EFFECT_TORCH_CUDA_ROUTER_BITONIC=1
export EFFECT_TORCH_CUDA_WIDE_ARG_FUSION=1
export EFFECT_TORCH_CUDA_RMS_VECTOR_LOADS=1
export EFFECT_TORCH_CUDA_ORDERED_SCATTER_FUSION=1
export EFFECT_TORCH_CUDA_ORDERED_SCATTER_ROUTE_MAP=1
export EFFECT_TORCH_CUDA_ORDERED_SCATTER_WEIGHTED=1
export EFFECT_TORCH_CUDA_F32_BF16_BITS=1
export EFFECT_TORCH_CUDA_EXPERT_GEMV=0
export EFFECT_TORCH_CUDA_OVERLAP_PRIMARY_GRAPHS=0
export EFFECT_TORCH_CUDA_EXPERT_SEQUENCE_GRAPHS=0
export EFFECT_TORCH_CUDA_EXPERT_BRANCH_GRAPHS=0
if [[ "$stage" == capture ]]; then
  export REPLAY_MODE=capture
  unset OUTPUT
else
  export REPLAY_MODE=timing
  export OUTPUT=${prefix}.jsonl
fi
exec pnpm --filter @effect-torch/bench exec tsx diffusion-gemma/controlled-replay-direct.ts > "${prefix}.log" 2>&1
