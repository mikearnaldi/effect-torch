"""Execute exact receipt guards with valid release and rejected debug/mismatched fixtures."""
import ast,copy,json
from pathlib import Path
source=Path(__file__).with_name('run.py').read_text();tree=ast.parse(source)
start=source.index("assert manifest['archiveSha256']")
end=source.index("candidate=a.build/",start)
checks=source[start:end]
profile={'optLevel':3,'lto':True,'codegenUnits':1,'debugAssertions':False,'overflowChecks':False,'debug':0,'incremental':False,'panic':'unwind'}
addon=None
# Extract the addon equality literal without hardcoding the eventual pinned hash.
for node in ast.walk(tree):
 if isinstance(node,ast.Compare) and isinstance(node.left,ast.Subscript) and ast.unparse(node.left)=="hardware['candidateSha256']":addon=node.comparators[-1].value
assert addon
sha='54979d50b5cb2e5ae68ece16540d26150957210dc42c4cbfb74508067a3e337e'
receipt=dict(sourceArchiveSha256=sha,profile='release',buildProfile=profile,artifactSubdirectory='x86_64-unknown-linux-gnu/release',buildCommand=['cargo','build','--release'],sha256=addon)
hardware={**receipt,'status':'passed','candidateSha256':addon,'checks':['host','chain97-parity','normrope101-loader-parity','normrope101-compiled-lifecycle','normrope101-lazy-kv-schedule','normrope101-actual-model-tables-kv','softmax100-loader-parity','softmax100-compiled-lifecycle']}
def run(r,h):exec(checks,dict(manifest={'archiveSha256':sha},receipt=r,hardware=h))
run(receipt,hardware);cases=1
for target,key,value in [('receipt','profile','debug'),('hardware','profile','debug'),('receipt','artifactSubdirectory','x86_64-unknown-linux-gnu/debug'),('receipt','buildCommand',['cargo','build']),('hardware','checks',hardware['checks'][1:]),('hardware','buildProfile',{**profile,'optLevel':0})]:
 r,h=copy.deepcopy(receipt),copy.deepcopy(hardware);(r if target=='receipt' else h)[key]=value
 try:run(r,h)
 except AssertionError:cases+=1
 else:raise AssertionError((target,key,'accepted invalid receipt'))
print(json.dumps(dict(status='passed',cases=cases,scope='exact release profile/hardware admission guards')))
