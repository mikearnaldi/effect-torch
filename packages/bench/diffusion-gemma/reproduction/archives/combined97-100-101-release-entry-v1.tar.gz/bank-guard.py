#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
command, repository, output_root = sys.argv[1:]
repository, output_root = Path(repository).resolve(), Path(output_root).resolve()
source = json.loads((here / 'source-guards.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

if command == 'sources':
    for name, digest in {**source['nativeFiles'], **source['harnessFiles']}.items():
        require(sha(repository / name) == digest, f'source mismatch: {name}')
    require(sha(repository / 'packages/backend-cuda/dist/internal/effect-torch-backend-cuda.linux-x64-gnu.node') == source['normalAddonSHA256'], 'normal66 addon mismatch')
    for name, digest in source['externalFiles'].items():
        require(sha(Path(name)) == digest, f'external artifact mismatch: {name}')
elif command == 'manifest':
    base = json.loads((here / 'manifest-source.json').read_text())
    seeds = json.loads((here / 'declared-seeds.json').read_text())
    for target in (32, 128):
        point = output_root / f'prompt-{target}'
        expected = json.loads(json.dumps(base))
        expected['matrix'].update(promptTargets=[target], outputTokens=[64], concurrencies=[1], warmupRuns=2, measuredRuns=5)
        require(json.loads((point / 'benchmark.json').read_text()) == expected, f'point manifest changed: {target}')
        require(json.loads((point / 'case-plan.json').read_text())['cases'] == seeds[str(target)], 'declared seeds differ')
elif command == 'bank':
    for target in (32, 128):
        point = output_root / f'prompt-{target}'
        plan = json.loads((point / 'case-plan.json').read_text())
        paths = [point/'bank'/f"prompt-{target}-seed-{case['seed']}"/'manifest.json' for case in plan['cases']]
        require(set((point/'bank').glob('**/manifest.json')) == set(paths), 'unexpected/partial bank inventory')
        inventory = []
        for case, path in zip(plan['cases'], paths):
            record, digest = json.loads(path.read_text()), sha(path)
            require(record['request']['seed'] == case['seed'], 'bank seed mismatch')
            require(len(record['request']['promptTokenIds']) == target and record['request']['maxNewTokens'] == 64, 'bank request geometry mismatch')
            inventory.append({'run': case['run'], 'seed': case['seed'], 'manifestSha256': digest, 'refinements': len(record['steps'])})
        seal = point / 'native66-bank-seal.json'
        require(seal.exists(), 'existing captured bank seal required')
        require(json.loads(seal.read_text()) == inventory, 'shared bank changed after capture')
else:
    raise RuntimeError(f'unknown guard {command}')
print(f'{command}: verified')
