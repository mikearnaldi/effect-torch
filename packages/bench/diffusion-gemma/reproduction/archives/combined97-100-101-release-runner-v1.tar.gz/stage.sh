#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "${here}/../../.." && pwd)
cd "${repo}"
nix develop .#cuda --command ./scripts/cuda-devbox.sh run mkdir /root/combined97-100-101-release-build-v1
tar -C "${here}" -czf - profile.py build.py validate.py stage.sh README.txt local-checks.json runner-hashes.json source-v1-manifest.json source-v1.tar.gz |
  nix develop .#cuda --command ./scripts/cuda-devbox.sh run tar -xzf - -C /root/combined97-100-101-release-build-v1
