"""Root invokes on the devbox only when its build/GPU schedule permits."""
import argparse, hashlib, json, os, shutil, subprocess, tarfile
from pathlib import Path
from profile import PROFILE, build_environment
p = argparse.ArgumentParser()
p.add_argument('--target-dir', default='/root/whole-read71-build-v1/target')
a = p.parse_args()
here = Path(__file__).resolve().parent
source = here / 'source-v1'
candidate = here / 'combined97-100-101-release-v1.node'
assert not source.exists() and not candidate.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runner_hashes = json.loads((here / 'runner-hashes.json').read_text())
for name, digest in runner_hashes.items(): assert sha(here / name) == digest, name
manifest = json.loads((here / 'source-v1-manifest.json').read_text())
assert sha(here / 'source-v1.tar.gz') == manifest['archiveSha256']
source.mkdir()
with tarfile.open(here / 'source-v1.tar.gz') as archive: archive.extractall(source, filter='data')
for name, digest in manifest['files'].items():
    assert sha(source / name) == digest, name
    os.utime(source / name, None)
env, profile_receipt = build_environment(source, a.target_dir)
with (here / 'build.log').open('x') as log:
    subprocess.run(['cargo', 'build', '--release', '--verbose', '--locked', '--target', 'x86_64-unknown-linux-gnu', '-p',
        'effect-torch-runtime-cuda', '--features', 'napi-addon'], cwd=source, env=env,
        stdout=log, stderr=subprocess.STDOUT, check=True)
assert 'Finished `release` profile [optimized' in (here / 'build.log').read_text(), 'release optimization label missing'
for name, digest in manifest['files'].items(): assert sha(source / name) == digest, name
shutil.copyfile(Path(a.target_dir) / 'x86_64-unknown-linux-gnu/release/libeffect_torch_runtime_cuda.so', candidate)
receipt = {'candidate': str(candidate), 'sha256': sha(candidate), 'targetDirectory': a.target_dir,
           'sourceArchiveSha256': manifest['archiveSha256'], **profile_receipt, 'buildCommand':['cargo','build','--release','--verbose','--locked','--target','x86_64-unknown-linux-gnu','-p','effect-torch-runtime-cuda','--features','napi-addon']}
(here / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
