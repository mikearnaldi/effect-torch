"""Audited, explicit release profile; no source or CUDA runtime policy changes."""
import hashlib, os, subprocess, tomllib
from pathlib import Path
PROFILE = {'optLevel':3,'lto':True,'codegenUnits':1,'debugAssertions':False,'overflowChecks':False,'debug':0,'incremental':False,'panic':'unwind'}
def build_environment(source, target_dir):
    env = {k:v for k,v in os.environ.items() if not k.startswith(('EFFECT_TORCH_','CUPTI_','REPLAY_','DIFFUSION_')) and k!='CUDA_INJECTION64_PATH'}
    removed=[]
    for key in list(env):
        if key.startswith('CARGO_PROFILE_') or (key.startswith('CARGO_TARGET_') and key.endswith('_RUSTFLAGS')) or key in {'RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','CARGO_TARGET_DIR','RUSTC','CARGO_BUILD_RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER'}:
            removed.append(key);del env[key]
    env.update(RUSTUP_TOOLCHAIN='1.93.1',CARGO_TARGET_DIR=str(target_dir),CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_LTO='true',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1',CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS='false',CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='false',CARGO_PROFILE_RELEASE_DEBUG='0',CARGO_PROFILE_RELEASE_INCREMENTAL='false',CARGO_PROFILE_RELEASE_PANIC='unwind')
    source=Path(source).resolve()
    cargo_home=Path(env.get('CARGO_HOME',str(Path.home()/'.cargo')))
    configs={d/'.cargo'/n for d in (source,*source.parents) for n in ('config','config.toml')}
    configs.update(cargo_home/n for n in ('config','config.toml'))
    digests={}
    for path in sorted(configs):
        if not path.exists():continue
        data=path.read_bytes();config=tomllib.loads(data.decode())
        assert not config.get('profile'),f'Cargo profile override: {path}'
        assert not any(k in config.get('build',{}) for k in ('rustflags','rustc','rustc-wrapper','rustc-workspace-wrapper')),f'Cargo build override: {path}'
        assert not any('rustflags' in t for t in config.get('target',{}).values()),f'Cargo target flags override: {path}'
        digests[str(path)]=hashlib.sha256(data).hexdigest()
    manifest=tomllib.loads((source/'Cargo.toml').read_text())
    assert manifest['profile']['release']=={'lto':True,'codegen-units':1}
    version=subprocess.check_output(['rustc','-vV'],env=env,cwd=source,text=True)
    assert 'release: 1.93.1' in version
    return env,{'profile':'release','buildProfile':PROFILE,'artifactSubdirectory':'x86_64-unknown-linux-gnu/release','rustcVersion':version,'removedBuildOverrideKeys':sorted(removed),'cargoConfigSha256':digests}
