"""Exports PTX and runs isolated Rust hardware tests. Never swaps the addon."""
import argparse, hashlib, json, os, shutil, signal, subprocess
from pathlib import Path
from profile import PROFILE, build_environment
p = argparse.ArgumentParser()
p.add_argument('--normrope101-directory', default='/root/triton-normrope101-fulltables-screen-v2')
p.add_argument('--softmax100-directory', default='/root/triton-softmax100-screen-v1')
p.add_argument('--python', default='/root/.cache/effect-torch/vllm-0.24.0/bin/python')
p.add_argument('--addon', default='/root/effect-torch/packages/backend-cuda/dist/internal/effect-torch-backend-cuda.linux-x64-gnu.node')
p.add_argument('--addon-sha', default='bdb5d1e21325b747fc989514bb2fad14b38796a1d1a8af3b73ee299303968d8a')
a = p.parse_args()
here = Path(__file__).resolve().parent
source, out, ptx = here / 'source-v1', here / 'hardware', here / 'ptx-abi2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runner_hashes = json.loads((here / 'runner-hashes.json').read_text())
for name, digest in runner_hashes.items(): assert sha(here / name) == digest, name
manifest = json.loads((here / 'source-v1-manifest.json').read_text())
receipt = json.loads((here / 'build-receipt.json').read_text())
assert receipt['profile']=='release' and receipt['buildProfile']==PROFILE
assert receipt['artifactSubdirectory']=='x86_64-unknown-linux-gnu/release'
addon = Path(a.addon)
candidate = here / 'combined97-100-101-release-v1.node'
def guard():
    normrope101 = Path(a.normrope101_directory)
    assert sha(normrope101/'launch-manifest.json')=='9476c087a7c5af33f2e4521833faee6d4cd048b1cb483751fe29388fca482aa4'
    for name,digest in {'reduction.ptx':'71925415c29170bbdc09bffba6eb75f3b8670a4b32e3227b074c6b3056099889','pointwise.ptx':'b5c757f91fc75f56e4fb06b131ec21a53d1f739eea4ce9e631b8329fb58b947a','helpers.ptx':'c3984b2208ee1cdeb4094fb975be3136b2cbe604dafbb744f6fad0bd0a9f5e33'}.items():assert sha(normrope101/name)==digest
    softmax100 = Path(a.softmax100_directory)
    for row in json.loads((softmax100 / 'launch-manifest.json').read_text())['variants']:
        assert sha(softmax100 / row['file']) == row['sha256']
    shared_ptx = Path('/root/combined87-build-v3/ptx-abi2')
    assert sha(shared_ptx / 'manifest.json') == 'cce0b9a39331788858ffe9a032a816a6918ff9b9d3cf47d96cd899efc7db4fed'
    for row in json.loads((shared_ptx / 'manifest.json').read_text())['variants']:
        assert sha(shared_ptx / row['ptx']) == row['sha256']
    for name, digest in runner_hashes.items(): assert sha(here / name) == digest, name
    assert sha(addon) == a.addon_sha, 'production addon changed'
    assert sha(candidate) == receipt['sha256'], 'isolated addon changed'
    assert receipt['sourceArchiveSha256'] == manifest['archiveSha256']
    assert sha(here / 'source-v1.tar.gz') == manifest['archiveSha256']
    for name, digest in manifest['files'].items(): assert sha(source / name) == digest, name
guard()
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip(), 'GPU busy'
out.mkdir()
env, validation_profile = build_environment(source, receipt['targetDirectory'])
assert validation_profile['buildProfile']==receipt['buildProfile']
assert validation_profile['cargoConfigSha256']==receipt['cargoConfigSha256']
assert validation_profile['rustcVersion']==receipt['rustcVersion']
def run(name, command, flags=None):
    with (out / (name + '.log')).open('x') as log:
        child = subprocess.Popen(command, cwd=source, env={**env, **(flags or {})}, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try: code = child.wait()
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try: child.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait()
    guard()
    if name != 'export' and code == 0:
        import re
        results = re.findall(r'test result: ok\. (\d+) passed', (out / (name + '.log')).read_text())
        assert results and int(results[-1]) >= (223 if name == 'host' else 1), f'{name}: missing expected tests'
    assert code == 0, f'{name} failed; see {out / (name + ".log")}'
    print(name + ' passed', flush=True)
ptx = Path('/root/combined87-build-v3/ptx-abi2')
assert sha(ptx / 'manifest.json') == 'cce0b9a39331788858ffe9a032a816a6918ff9b9d3cf47d96cd899efc7db4fed'
ptx_manifest = json.loads((ptx / 'manifest.json').read_text())
for row in ptx_manifest['variants']: assert sha(ptx / row['ptx']) == row['sha256']
base = ['cargo', 'test', '--release', '--locked', '--target', 'x86_64-unknown-linux-gnu', '-p', 'effect-torch-runtime-cuda', '--features', 'napi-addon', '--lib']
ignored = ['--', '--ignored', '--nocapture', '--test-threads=1']
checks = [
 ('host', {}, ['--', '--test-threads=1']),
 ('chain97-parity', {}, ['chain97_hardware_upload_readback_cancellation', *ignored]),
 ('normrope101-loader-parity', {'EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY': a.normrope101_directory}, ['normrope101_hardware_fixed_images_preserve_inputs_and_retained_outputs', *ignored]),
 ('normrope101-compiled-lifecycle', {'EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY': a.normrope101_directory, 'EFFECT_TORCH_CUDA_PACKED_PROJECTION77':'1', 'EFFECT_TORCH_CUDA_NORM_ROPE':'1', 'EFFECT_TORCH_CUDA_NORM_ROPE_MASK':'1'}, ['normrope101_hardware_compiled_lifecycle', *ignored]),
 ('normrope101-lazy-kv-schedule', {'EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY': a.normrope101_directory, 'EFFECT_TORCH_CUDA_PACKED_PROJECTION77':'1', 'EFFECT_TORCH_CUDA_NORM_ROPE':'1', 'EFFECT_TORCH_CUDA_NORM_ROPE_MASK':'1'}, ['normrope101_hardware_lazy_kv_schedule', *ignored]),
 ('normrope101-actual-model-tables-kv', {'EFFECT_TORCH_CUDA_TRITON_NORMROPE101_DIRECTORY': a.normrope101_directory, 'EFFECT_TORCH_CUDA_PACKED_PROJECTION77':'1', 'EFFECT_TORCH_CUDA_NORM_ROPE':'1', 'EFFECT_TORCH_CUDA_ROTARY_REUSE66':'1', 'EFFECT_TORCH_CUDA_RMS_VECTOR_LOADS':'1', 'EFFECT_TORCH_CUDA_RMS_STATIC2816':'1'}, ['normrope101_hardware_actual_model_tables_kv', *ignored]),
 ('softmax100-loader-parity', {'EFFECT_TORCH_CUDA_TRITON_SOFTMAX100_DIRECTORY': a.softmax100_directory}, ['softmax100_hardware_fixed_images_preserve_inputs_and_retained_outputs', *ignored]),
 ('softmax100-compiled-lifecycle', {'EFFECT_TORCH_CUDA_TRITON_SOFTMAX100_DIRECTORY': a.softmax100_directory, 'EFFECT_TORCH_CUDA_BF16_SOFTMAX':'1'}, ['softmax100_hardware_compiled_lifecycle_cancellation_and_retained_outputs', *ignored]),
]
for name, flags, extra in checks: run(name, base + extra, flags)
assessment = {**validation_profile, 'status': 'passed', 'sourceArchiveSha256': manifest['archiveSha256'],
    'candidateSha256': sha(candidate), 'checks': [c[0] for c in checks],
    'abi2ManifestSha256': sha(ptx / 'manifest.json'),
    'normrope101ManifestSha256': sha(Path(a.normrope101_directory) / 'launch-manifest.json'),
    'softmax100ManifestSha256': sha(Path(a.softmax100_directory) / 'launch-manifest.json'),
    'normalAddonUnchanged': sha(addon) == a.addon_sha,
    'scope': 'Hardware numerical/lifetime checks only; full-model hashes and matched timing remain separate'}
(out / 'assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
print(json.dumps(assessment))
